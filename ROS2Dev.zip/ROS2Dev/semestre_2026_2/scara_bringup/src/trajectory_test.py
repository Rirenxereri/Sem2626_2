#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64, Float64MultiArray

class TrayTestMatlab(Node):

    def __init__(self):
        super().__init__('tray_test')
        
        # Publicadores a los motores
        self.pub_j1 = self.create_publisher(Float64, '/joint1/cmd_pos', 10)
        self.pub_j2 = self.create_publisher(Float64, '/joint2/cmd_pos', 10)
        self.pub_j3 = self.create_publisher(Float64, '/joint3/cmd_pos', 10)
        
        # Telemetría
        self.status_publisher = self.create_publisher(Float64MultiArray, '/scara_status', 10)
        
        self.timer = self.create_timer(0.5, self.timer_callback)
        
        # Trayectoria de 11 puntos (Valores que ya habíamos validado)
        self.q1 = [0.618907, 0.647881, 0.711192, 0.807880, 0.927295, 1.050581, 1.155955, 1.227275, 1.260392, 1.266104, 1.273801]
        self.q2 = [2.405896, 2.417346, 2.440232, 2.469835, 2.498092, 2.518262, 2.528500, 2.531739, 2.532197, 2.532207, 2.532189]
        self.q3 = [-3.024803, -3.065227, -3.151425, -3.277715, -3.425387, -3.568843, -3.684455, -3.759014, -3.792589, -3.798311, -3.805990]
        
        self.index = 0
        self.get_logger().info('Nodo SCARA Adaptado inicializado. Listo para publicar.')

    def timer_callback(self):
        if self.index >= len(self.q1):
            self.index = 0

        # Obtener valores
        v1, v2, v3 = self.q1[self.index], self.q2[self.index], self.q3[self.index]

        # Publicar motores
        self.pub_j1.publish(Float64(data=float(v1)))
        self.pub_j2.publish(Float64(data=float(v2)))
        self.pub_j3.publish(Float64(data=float(v3)))
        
        # Publicar telemetría
        status_msg = Float64MultiArray()
        status_msg.data = [v1, v2, v3]
        self.status_publisher.publish(status_msg)
        
        self.get_logger().info(f'Punto {self.index+1}: J1={v1:.3f}, J2={v2:.3f}, J3={v3:.3f}')
        self.index += 1

def main(args=None):
    rclpy.init(args=args)
    node = TrayTestMatlab()
    rclpy.spin(node)
    node.destroy_node()
    rclpy.shutdown()

if __name__ == '__main__':
    main()